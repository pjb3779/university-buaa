#include <stdio.h>
void output1();
void output2();
void output3();
void output4();
void output5();
void output6();
void output7();
void output8();
void output9();
void output10();
void output11();
void output12();
void output13();
void output14();
void output15();
int main() {
  output1();
  output4();
  output13();
  output15();
  output11();
  output9();
  output12();
  output3();
  output7();
  output2();
  output6();
  output10();
  output14();
  output5();
  output8();
  return 0;
}
