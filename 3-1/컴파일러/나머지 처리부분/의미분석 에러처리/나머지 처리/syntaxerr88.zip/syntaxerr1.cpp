#include <iostream>
#include <stdio.h>
#include <cstring>
#include <string>
#include <cstdlib>
#include <cctype>
#include <fstream>
#include <sstream>
#include <algorithm>

using namespace std;

void init();
void Lexical_Analysis();
void Lexical_Analysis_run();
void skipBlank();
void check_LineNum();
void push_TypeToken();
void push_Token_list(string Token, string word);
void print_Lexical();
bool check_Char_Type(int check);
void skip_line_Comment();
void skip_block_Comment();
void push_err_list(char err_type);
void output_Lexical();
void output_Syntax();
void Syntax_Analysis();
void nextToken();
void preToken();
void printcurToken();
void printSyntax(string syntax);
void parseCompUnit();
void parseDecl();
void parseConstDecl();
void parseBType();
void parseConstDef(int type, int kind);
void parseConstInitVal();
void parseVarDecl();
void parseVarDef(int type, int kind);
void parseInitVal();
void parseFuncDef();
void parseMainFuncDef();
void parseFuncType();
void parseFuncType();
void parseFuncFParams();
void parseFuncFParam();
void parseBlock();
void parseBlockItem();
void parseStmt();
void parseForStmt();
int parseExp();
void parseCond();
int parseLVal(int type);
int parsePrimaryExp(int type);
void parseNumber();
void parseCharacter();
int parseUnaryExp(int type);
void parseUnaryOp();
int parseFuncRParams();
int parseMulExp(int type);
int parseAddExp(int type);
void parseRelExp();
void parseEqExp();
void parseLAndExp();
void parseLOrExp();
void parseConstExp();
void parseErrorA();
bool parseErrorB(string name, int type, int kind, int isconst, int nowScope);
void parseErrorC(string name);
void parseErrorD(int funcline);
void parseErrorE(int param_num);
void parseErrorF(int linenum);
void parseErrorG();
void parseErrorH(string name);
void parseErrorI();
bool parseErrorJ();
void parseErrorK();
void parseErrorL(string formatString, int print_param_cnt, int printlinenum);
void parseErrorM();
void print_err_list();

ifstream inputFile;
ofstream outputFile;
ofstream outputFile2;
ofstream errorFile;
string input_text = "";
string Token = "";

int input_text_len = 0;
int curpos = 0;
int glb_linenum = 1;
int last_nonT;

enum KindEnum {
	VAR,
	FUNC,
	PARAM,
	ARR
};

enum TypeEnum {
	INT,
	CHAR,
	VOID
};

struct Token_word {
    string Token;
    string word;
    int line_num;
}; 
Token_word Token_list[100001];
int Tlist_top = 0;
Token_word curToken;

struct error_word{
	int linenum;
	char err_type;
};
error_word error_list[100001];
int err_top = 0;

struct SymbolTable{
	string name;
	int type = -1;	//0 = int, 1 = char, 2 = void
	int kind = -1;	//0 = var, 1 = func, 2 = param, 3 = arr
	int isconst = 0;	//cosnt = 1, not const = 0
	int scope;
};
SymbolTable symbolTable[100001];
SymbolTable SymbolTemp;
SymbolTable printfSymbol[10001];
int print_top = 0;

int ST_top = 0;		//symbotabletop
int glb_SS= 1;	//symbol_scope	���� �����Ҷ�����++ 
int curScope = 1;	
int funcStartScope = 0; //�Լ����۽� ������
int last_func_line; //errord ó�� 

bool isglbscope = true;		//����������� 
bool isequalScope = false;	//�Լ� ���� �������� ������ 

bool isneedreturn = true;		//������ �ʿ��� �Լ��Ǵ� 
bool isstmtreturn = false;		// stmt�� ������ ���Դ��� �Ǵ� 
bool isBorC = false;			// �극��ũ�� ��Ƽ������  
bool isfuncparam = false;
bool isfuncDef = false;		//����eó�� �Լ��������� �ƴ��� Ȯ�� 
bool isifelse = false;		//if else�� ���� ���� 
struct funcparam{
	int type;
	string name;
	int paramcnt = 0;
	vector<int> paramtype;
	vector<int> paramkind;
	int expectedcnt = 0;
};
funcparam funcInfo[100001];
int funcInfo_top = 0;
vector<funcparam> funcparse;

void add_s_Table(string name, int type, int kind, int isconst){
	symbolTable[ST_top].name = name;
	symbolTable[ST_top].type = type;
	symbolTable[ST_top].kind = kind;
	symbolTable[ST_top].isconst = isconst;
	if(isglbscope){
		symbolTable[ST_top].scope = 1;
	}else if(isequalScope) {
		symbolTable[ST_top].scope = curScope;
	}else {
		symbolTable[ST_top].scope = glb_SS;
	}
	ST_top++;
}

void push_Token_list(string Token, string word) {
    Token_list[Tlist_top].Token = Token;
    Token_list[Tlist_top].word = word;
    Token_list[Tlist_top].line_num = glb_linenum;
    Tlist_top++;
}

void push_err_list(char err_type) {
    error_list[err_top].err_type = err_type;
    error_list[err_top].linenum = curToken.line_num;
    err_top++;
}

void push_err_list(char err_type, int err_line) {
    error_list[err_top].err_type = err_type;
    error_list[err_top].linenum = err_line;
    err_top++;
}

bool compareErrLine(const error_word& a, const error_word& b) {
    return a.linenum < b.linenum;
}

//void print_err_list(){
//	sort(error_list, error_list + err_top, compareErrLine);
//	
//	for(int i = 0; i < err_top ; i++){
//		cout << error_list[i].linenum << " " << error_list[i].err_type << endl;
//		errorFile << error_list[i].linenum << " " << error_list[i].err_type << endl;
//	}
//}
void print_err_list() {
    // ���� ����Ʈ�� ���� ���ĺ������� ������ ����, �� ��ȣ�� �������� �ٽ� ����
    sort(error_list, error_list + err_top, [](const error_word& a, const error_word& b) {
        if (a.linenum == b.linenum) {
            return a.err_type < b.err_type; // ���� �ٿ����� ���� ������ ���ĺ� ������ ����
        }
        return a.linenum < b.linenum; // �� ��ȣ�� �������� ����
    });

    int last_line = -1; // ������ ��µ� �� ��ȣ

    for (int i = 0; i < err_top; i++) {
        int line_num = error_list[i].linenum;
        char err_type = error_list[i].err_type;

        // ������ ���� �ٿ����� ������ �ǳʶ�
        if (line_num == last_line) {
            continue;
        }

        // ���� ���
        cout << line_num << " " << err_type << endl;
        errorFile << line_num << " " << err_type << endl;

        // ������ ��µ� �� ��ȣ ����
        last_line = line_num;
    }
}

bool compareSymbolScope(const SymbolTable &a, const SymbolTable &b){
	return a.scope < b.scope;
}

void print_symbol_list(){
	stable_sort(symbolTable, symbolTable + ST_top, compareSymbolScope);
	
	for(int i = 0; i < ST_top ; i++){
		string temp;
		if(symbolTable[i].isconst == 1){
			if(symbolTable[i].type == 0 && symbolTable[i].kind == 0){
    			temp = "ConstInt";
			} else if(symbolTable[i].type == 0 && symbolTable[i].kind == 3){
	   	 		temp = "ConstIntArray";
			} else if(symbolTable[i].type == 1 && symbolTable[i].kind == 0){
	    		temp = "ConstChar";
			} else if(symbolTable[i].type == 1 && symbolTable[i].kind == 3){
    			temp = "ConstCharArray";
			}
		} else if(symbolTable[i].type == 0 && symbolTable[i].kind == 0){
    		temp = "Int";
		} else if(symbolTable[i].type == 0 && symbolTable[i].kind == 3){
    		temp = "IntArray";
		} else if(symbolTable[i].type == 1 && symbolTable[i].kind == 0){
	   	 	temp = "Char";
		} else if(symbolTable[i].type == 1 && symbolTable[i].kind == 3){
    		temp = "CharArray";
		} else if(symbolTable[i].type == 0 && symbolTable[i].kind == 1){
   		 	temp = "IntFunc";
		} else if(symbolTable[i].type == 1 && symbolTable[i].kind == 1){
    		temp = "CharFunc";
		} else if(symbolTable[i].type == 2 && symbolTable[i].kind == 1){
    		temp = "VoidFunc";
		} 
		cout << symbolTable[i].scope << " " 
		<< symbolTable[i].name << " " 
		<< temp << endl;
		
		outputFile2 << symbolTable[i].scope << " " 
		<< symbolTable[i].name << " " 
		<< temp << endl;
	}
}

void Lexical_Analysis_run() {
	char err_type = 'a';
    Token = "";
    if (isalpha(input_text[curpos]) || input_text[curpos] == '_') {
        while (isdigit(input_text[curpos]) || isalpha(input_text[curpos]) || input_text[curpos] == '_') {
            Token += input_text[curpos];
            curpos++;
        }
        push_TypeToken();
    } 
	// if test has float
        /* bool isFloat = false;
        while(isdigit(input_text[curpos])||input_text[curpos]=='.') {
            if(input_text[curpos]=='.')
                isFloat = true;
            token += input_text[curpos];
            curpos++;
		}
        if(isFloat)
        {
    		push_Token_list("FLOATCON?", Token);
        }
        else{
            push_Token_list("INTCON", Token);
        } */ 
	else if(isdigit(input_text[curpos])){
		while(isdigit(input_text[curpos])){
			Token += input_text[curpos];
			curpos++;
		}
		push_Token_list("INTCON", Token);
	} else if(input_text[curpos] == '"'){
		Token += input_text[curpos];
		curpos++;
		while(input_text[curpos] != '"'){
			Token += input_text[curpos];
			curpos++;
		}
		Token += input_text[curpos];
		curpos++;
		push_Token_list("STRCON", Token);
	} else if(input_text[curpos] == '&') {
		if(input_text[curpos + 1] == '&'){
			push_Token_list("AND", "&&");
        	curpos += 2;	
		} else{
//			push_err_list(err_type);	���ֺм��� ���� �ּ������� �����м��� ������ �ߺ� ��� 
			push_Token_list("EAND", "&");
			curpos++;
		}
    } else if(input_text[curpos] == '|'){
        if(input_text[curpos + 1] == '|'){
			push_Token_list("OR", "||");
        	curpos += 2;	
		} else{
//			push_err_list(err_type);
			push_Token_list("EOR", "|");
			curpos++;
		}
    } else if(input_text[curpos] == '+') {
        push_Token_list("PLUS", "+");
        curpos++;
    } else if(input_text[curpos] == '-') {
        push_Token_list("MINU", "-");
        curpos++;
    } else if(input_text[curpos] == '*') {
        push_Token_list("MULT", "*");
        curpos++;
    } else if(input_text[curpos] == '/') {
        if(input_text[curpos + 1] == '/'){
        	skip_line_Comment();
		} else if(input_text[curpos + 1] == '*'){
			skip_block_Comment();
		} else{
			push_Token_list("DIV", "/");
        	curpos++;
		}
    } else if(input_text[curpos] == '%') {
        push_Token_list("MOD", "%");
        curpos++;
    } else if(input_text[curpos] == ';') {
        push_Token_list("SEMICN", ";");
        curpos++;
    } else if(input_text[curpos] == ',') {
        push_Token_list("COMMA", ",");
        curpos++;
    } else if(input_text[curpos] == '(') {
        push_Token_list("LPARENT", "(");
        curpos++;
    } else if(input_text[curpos] == ')') {
        push_Token_list("RPARENT", ")");
        curpos++;
    } else if(input_text[curpos] == '[') {
        push_Token_list("LBRACK", "[");
        curpos++;
    } else if(input_text[curpos] == ']') {
        push_Token_list("RBRACK", "]");
        curpos++;
    } else if(input_text[curpos] == '{') {
        push_Token_list("LBRACE", "{");
        curpos++;
    } else if(input_text[curpos] == '}') {
        push_Token_list("RBRACE", "}");
        curpos++;
    } else if(input_text[curpos] == '!') {
        if (input_text[curpos + 1] == '=') {
            push_Token_list("NEQ", "!=");
            curpos += 2;
        } else{
            push_Token_list("NOT", "!");
            curpos++;
        }
    } else if(input_text[curpos] == '<') {
        if(input_text[curpos + 1] == '=') {
            push_Token_list("LEQ", "<=");
            curpos += 2;
        } else{
            push_Token_list("LSS", "<");
            curpos++;
        }
    } else if(input_text[curpos] == '>') {
        if(input_text[curpos + 1] == '=') {
            push_Token_list("GEQ", ">=");
            curpos += 2;
        } else{
            push_Token_list("GRE", ">");
            curpos++;
        }
    } else if(input_text[curpos] == '=') {
        if(input_text[curpos + 1] == '=') {
            push_Token_list("EQL", "==");
            curpos += 2;
        } else{
            push_Token_list("ASSIGN", "=");
            curpos++;
        }
    } else if(input_text[curpos] == '\'') {
    Token = ""; 
    Token += '\''; 
    curpos++; 

    if(input_text[curpos] == '\\') {
	        Token += '\\';
	        curpos++;
	        if(input_text[curpos] == 'n' || input_text[curpos] == 't' || input_text[curpos] == 'v' ||
	           input_text[curpos] == '\\' || input_text[curpos] == '\'' || input_text[curpos] == '\"' ||
	           input_text[curpos] == 'a' || input_text[curpos] == 'b' || 
	           input_text[curpos] == '0' || input_text[curpos] == 'f') {
	            Token += input_text[curpos];
	            curpos++;
	        }
	    } else {
	        int check_ASCII = input_text[curpos];
	        if(check_Char_Type(check_ASCII)) {
	            Token += input_text[curpos];
	            curpos++;
	        }
	    }

	    if(input_text[curpos] == '\'') {
	        Token += '\'';
	        curpos++;
	        push_Token_list("CHRCON", Token);
	   	}
	} else {
		curpos++;
	}
}

bool check_Char_Type(int check){
	if((check >= 32 && check <= 126 ) || (check >= 7 && check <= 12 ) || check == 34 
	|| check == 39 || check == 92 || check == 0) 
		return true;
	return false;
}

void push_TypeToken() {
    if(Token == "main") {
        push_Token_list("MAINTK", "main");
    } else if(Token == "const") {
        push_Token_list("CONSTTK", "const");
    } else if(Token == "int") {
        push_Token_list("INTTK", "int");
    } else if(Token == "char") {
        push_Token_list("CHARTK", "char");
    } else if(Token == "break") {
        push_Token_list("BREAKTK", "break");
    } else if(Token == "continue") {
        push_Token_list("CONTINUETK", "continue");
    } else if(Token == "if") {
        push_Token_list("IFTK", "if");
    } else if(Token == "else") {
        push_Token_list("ELSETK", "else");
    } else if(Token == "for") {
        push_Token_list("FORTK", "for");
    } else if(Token == "getint") {
        push_Token_list("GETINTTK", "getint");
    } else if(Token == "getchar") {
        push_Token_list("GETCHARTK", "getchar");
    } else if(Token == "printf") {
        push_Token_list("PRINTFTK", "printf");
    } else if(Token == "return") {
        push_Token_list("RETURNTK", "return");
    } else if(Token == "void") {
        push_Token_list("VOIDTK", "void");
    } else{
        push_Token_list("IDENFR", Token);
    }
}

void check_LineNum() {
    while(curpos < input_text_len && (input_text[curpos] == '\n')){
    	glb_linenum++;
    	curpos++;
	}
}

void skipBlank() {
    while (curpos < input_text_len &&
	(input_text[curpos] == ' ' || input_text[curpos] == '\t' || input_text[curpos] == '\r')) {
    	curpos++;
    }
}

void skip_line_Comment(){
	while(input_text[curpos] != '\n' && input_text[curpos] != '\r' && curpos < input_text_len){
		curpos++;
	}
}

void skip_block_Comment(){
	while(!(input_text[curpos] == '*' && input_text[curpos + 1] == '/') && curpos < input_text_len){
		curpos++;
	}
	if(curpos < input_text_len){
		curpos += 2;
	}
}

void print_Lexical() {
	if(err_top != 0){
		for(int i = 0; i < err_top; i++){
			cout << error_list[i].linenum << " " << error_list[i].err_type << "\n";
		}
	} else{
		for (int i = 0; i < Tlist_top; i++) {
        cout << Token_list[i].Token << " " << Token_list[i].word << " " << Token_list[i].line_num << "\n";
   		}
	}
}

void output_Lexical() {
	outputFile.open("lexer.txt");
    if (!outputFile.is_open()) {
        cerr << "can't open output file" << endl;
        return;
    }
	if(err_top != 0){
        for(int i = 0; i < err_top; i++){
            outputFile << error_list[i].linenum << " " << error_list[i].err_type << "\n";
        }
    } else {
        for (int i = 0; i < Tlist_top; i++) {
            outputFile << Token_list[i].Token << " " << Token_list[i].word << "\n";
        }
    }
}


void output_Syntax() {
	if(err_top != 0){
        for(int i = 0; i < err_top; i++){
            outputFile << error_list[i].linenum << " " << error_list[i].err_type << "\n";
        }
    } else {
        for (int i = 0; i < Tlist_top; i++) {
            outputFile << Token_list[i].Token << " " << Token_list[i].word << "\n";
        }
    }
}

void init() {
    inputFile.open("testfile.txt");
    if (!inputFile.is_open()) {
        cerr << "can't open file" << endl;
        return;
    }
	
	outputFile.open("parser.txt");
    if (!outputFile.is_open()) {
        cerr << "can't open output file" << endl;
        return;
    }
    
    outputFile2.open("symbol.txt");
    if (!outputFile2.is_open()) {
        cerr << "can't open symbol file" << endl;
        return;
    }
    
    errorFile.open("error.txt");
    if (!outputFile.is_open()) {
        cerr << "can't open output file" << endl;
        return;
    }
    
    string input_buffer;

    while (getline(inputFile, input_buffer)) {
    	input_text += input_buffer + "\n";
    }

    input_text_len = input_text.length();
}

void Lexical_Analysis() {
    while (curpos < input_text_len) {
    	skipBlank();       // ���� ���� �ǳʶٱ�
        check_LineNum();     // �ٹ�ȣ ó��  	
        
        // ��ū�� �νĵ��� �ʴ� ��쿡�� curpos�� �������� ���� ������ ����
        int previous_pos = curpos;
        Lexical_Analysis_run();
        
        // Lexical_Analysis_run �Լ��� curpos�� ������Ʈ���� �ʾ����� ������ ����
        if (curpos == previous_pos) {
            curpos++;
        }
        
        // ���� ���� üũ�Ͽ� ���� Ż��
        if (curpos >= input_text_len) {
            break;
        }
    }
}

//���� �м�
void Syntax_Analysis() {
	curpos = 0;
	curToken = Token_list[curpos];
	parseCompUnit();
}

void nextToken() {
	if (curpos + 1 <= Tlist_top) { // curpos�� Tlist_top�� �ʰ����� �ʵ��� ��ȣ
        curpos++;
        curToken = Token_list[curpos];
    } else {
        cerr << "Error: Token list out of range." << endl;
    }
}

void preToken() {
	if (curpos > 0) { // curpos�� 0���� �۾����� �ʵ��� ��ȣ
        curpos--;
        curToken = Token_list[curpos];
    } else {
        cerr << "Error: Token list out of range." << endl;
    }
}

void printcurToken() {
//	cout << Token_list[curpos].Token << " " << Token_list[curpos].word << endl;
	outputFile << Token_list[curpos].Token << " " << Token_list[curpos].word << "\n";
}

void printSyntax(string syntax) {
//	cout << "<" << syntax << ">" << endl;
	outputFile << "<" << syntax << ">" << endl;
}

// CompUnit �� {Decl} {FuncDef} MainFuncDef 
void parseCompUnit() {
	string temp1 = Token_list[curpos].Token;
	nextToken();
	string temp2 = Token_list[curpos].Token;
	nextToken();
	string temp3 = Token_list[curpos].Token;
	preToken();
	preToken();
	if(temp1 == "INTTK" && temp2 == "MAINTK"){
		parseMainFuncDef();
		printSyntax("CompUnit");
		return;
	} //�Լ����� ó�� 
	else if((temp1 == "INTTK" && temp3 == "LPARENT") || (temp1 == "CHARTK" && temp3 == "LPARENT") || (temp1 == "VOIDTK" && temp3 == "LPARENT")){
		parseFuncDef();
		parseCompUnit();
	} //����� ó�� 
	else{
		parseDecl();
		parseCompUnit();
	}
	
}

//Decl �� ConstDecl | VarDecl
void parseDecl() {
	if(curToken.Token == "INTTK" || curToken.Token == "CHARTK"){
		parseVarDecl();
	} else if(curToken.Token == "CONSTTK"){
		parseConstDecl();
	}
	
}

//ConstDecl �� 'const' BType ConstDef { ',' ConstDef } ';' // i
void parseConstDecl() {
	int type = -1;
	int kind = 0;
	
	printcurToken();//const
	nextToken();
	printcurToken();//Btype
	if(curToken.word == "int"){
		type = INT;
	} else {	//charó�� 
		type = CHAR;
	}
	nextToken();
	
	parseConstDef(type, kind);
	while(curToken.word == ","){ // ,�� ���Ӽ��� ó��  
		printcurToken();
		nextToken();
		parseConstDef(type, kind);
	}	
	
	parseErrorI(); //  ;
	
	printSyntax("ConstDecl");
}

//ConstDef �� Ident [ '[' ConstExp ']' ] '=' ConstInitVal // k
void parseConstDef(int type, int kind) {
	last_nonT = curToken.line_num;
	
	printcurToken();//Ident
	string identname = curToken.word;
	nextToken();
	
	if(curToken.word == "["){	//�迭 ���� ó�� 
		printcurToken();//[
		nextToken();
		
		parseConstExp();
		
		parseErrorK(); //  ]
		
		kind = 3;
	}
	
	parseErrorB(identname, type, kind, 1, glb_SS);
	
	printcurToken();//=
	nextToken();
		
	parseConstInitVal();
	
	printSyntax("ConstDef");
}

//ConstInitVal �� ConstExp | '{' [ ConstExp { ',' ConstExp } ] '}' | StringConst
void parseConstInitVal() {
	last_nonT = curToken.line_num;
	
	if(curToken.word == "{"){//�迭 ó�� 
		printcurToken();//{
		nextToken();
		
		if(curToken.word != "}"){
			parseConstExp();
		 
			while(curToken.word == ","){
				printcurToken();//	,
				nextToken();
	
				parseConstExp();
			}
		}
		
		printcurToken();//	}
		nextToken();
	} 
	// ������ڿ� ó�� 
	else if(curToken.Token == "STRCON"){
		printcurToken();// stringConst
		nextToken();
	} 
	//�׳� ���ó�� 
	else {
		parseConstExp();
	}
	
	printSyntax("ConstInitVal");
}

//VarDecl �� BType VarDef { ',' VarDef } ';' // i
void parseVarDecl() {	
	printcurToken(); // BType
	
	int type = -1;
	int kind = 0;
	if(curToken.word == "int"){
		type = INT;
	} else{		//char ó�� 
		type = CHAR;
	}
	
	nextToken();
	
	parseVarDef(type, kind);
	
	while(curToken.word == ","){
		printcurToken();	//,
		nextToken();
		
		parseVarDef(type, kind);
	}
	
	parseErrorI(); //  ;
	
	printSyntax("VarDecl");
};

//VarDef �� Ident [ '[' ConstExp ']' ] | Ident [ '[' ConstExp ']' ] '=' InitVal // k
void parseVarDef(int type, int kind) {
	last_nonT = curToken.line_num;
	
	printcurToken();//Ident
	string identname = curToken.word;
	nextToken();
	
	if(curToken.word == "["){	//�迭 ���� ó�� 
		printcurToken();//[
		nextToken();
		
		parseConstExp();
		
		parseErrorK(); //  ]
		kind = ARR;
	}
	
	parseErrorB(identname, type, kind, 0, glb_SS);
	
	if(curToken.word == "="){	//�迭 ���� + �ʱ�ȭ 
		printcurToken();//=
		nextToken();
		
		parseInitVal();
	} 
	// = ó�� ���� �����Ű�����? 
	printSyntax("VarDef");
}

//InitVal �� Exp | '{' [ Exp { ',' Exp } ] '}' | StringConst 
void parseInitVal() {
	if(curToken.word == "{"){//�迭 ó�� 
		printcurToken();//{
		nextToken();
		
		parseExp();
		 
		while(curToken.word == ","){
			printcurToken();//	,
			nextToken();
			
			parseExp();
		}
		
		printcurToken();//	}
		nextToken();
	} 
	// ������ڿ� ó�� 
	else if(curToken.Token == "STRCON"){
		printcurToken();// stringConst
		nextToken();
	} 
	//�׳� ���ó�� 
	else{
		parseExp();
	}
	printSyntax("InitVal");
}

//FuncDef �� FuncType Ident '(' [FuncFParams] ')' Block // j
void parseFuncDef() {
	int type = - 1;
	int kind = FUNC;
//	isfuncDef = true; 
	isstmtreturn = false;
	isneedreturn = true;
	
	if(curToken.word == "int" || curToken.word == "char" || curToken.word == "void"){
		if(curToken.word == "int"){
			type = INT;
		} else if(curToken.word == "char"){
			type = CHAR;
		} else{
			type = VOID;
			isneedreturn = false;
		}
		parseFuncType();
	}
	
	printcurToken();// Ident
	string identname = curToken.word;
	nextToken();
	
	funcInfo[funcInfo_top].type = type;
	funcInfo[funcInfo_top].name = identname;
	
	bool valid_func = false;
	if(parseErrorB(identname, type, kind, 0, 1)){
		valid_func = true;
	}
	
	printcurToken();// (
	last_nonT = curToken.line_num;
	glb_SS++;	//�Լ� �������� ó���� ����+ 
	curScope = glb_SS; 
	isglbscope = false;
	nextToken();
	
	if(curToken.word != ")" && curToken.word != "{"){
		parseFuncFParams();
	}
	
	parseErrorJ(); //  )
	
	glb_SS--;	//�Ű����� ó�� ���� 
	curScope = glb_SS; 
	funcStartScope = glb_SS + 1;
	parseBlock();
	
	curScope = glb_SS + 1; 
	isglbscope = true;
	
	if(valid_func){
		funcInfo_top++;	//�Լ����� ++	
	}
	
//	isfuncDef = false; 
	printSyntax("FuncDef");
}

//MainFuncDef �� 'int' 'main' '(' ')' Block // j
void parseMainFuncDef() {
	isneedreturn = true;
	isstmtreturn = false;	//�Լ� ���۽� false�� �ʱ�ȭ 
	
	printcurToken();// int
	nextToken();
		
	printcurToken();// main
	nextToken();
	
	printcurToken();// (
	last_nonT = curToken.line_num;
	nextToken();
	
	parseErrorJ(); //  )
	
	isglbscope = false; 
	curScope = glb_SS;
	funcStartScope = glb_SS + 1;
	
	parseBlock();
	
	isglbscope = true; 
	
	printSyntax("MainFuncDef");	
}

void parseFuncType() {
	printcurToken();// FuncType int void char
	nextToken();
	
	printSyntax("FuncType");	
}

//FuncFParams �� FuncFParam { ',' FuncFParam } 
void parseFuncFParams() {
	last_nonT = curToken.line_num;
	
	parseFuncFParam();
	
	while(curToken.word == ","){
		printcurToken();//	,
		nextToken();

		parseFuncFParam();
	}
	
	printSyntax("FuncFParams");		
}

//FuncFParam �� BType Ident ['[' ']'] // k
void parseFuncFParam() {
	printcurToken();//	BType
	int type = -1;
	if(curToken.word == "int"){
		type = INT;
	} else{
		type = CHAR;
	}
	nextToken();
	printcurToken();//	Ident
	string identname = curToken.word;
	nextToken();
	
	int kind = VAR;
	if(curToken.word == "["){
		printcurToken();//	[
		last_nonT = curToken.line_num;
		nextToken();
		
		parseErrorK();
		
		kind = ARR;
	}	
	parseErrorB(identname, type, kind, 0, glb_SS);
	funcInfo[funcInfo_top].paramtype.push_back(type);	//int = 0. char = 1
	funcInfo[funcInfo_top].paramkind.push_back(kind);   //var = 0, arr = 3 
	funcInfo[funcInfo_top].paramcnt++;

	printSyntax("FuncFParam");	
}

//'{' { BlockItem } '}' 
void parseBlock() {
	printcurToken();//	{
	glb_SS++;	//�����̸� ���� 
	curScope++;
	if(funcStartScope == curScope){
		isequalScope = true;
	} else{
		isequalScope = false;
	}
	nextToken();
	
	
	while (curToken.word != "}") {
		parseBlockItem();		
	}
	
	if(funcStartScope == curScope){		//�Լ��� ���Ͻ��������� ����üũ 
		parseErrorG();
	}
	
	printcurToken();//	}
	isstmtreturn = false;
	
	curScope--;
	if(funcStartScope == curScope){	//���� Ż���ҽ� �ٽ��ѹ� �� 
		isequalScope = true;
	}
	
	nextToken();
	
	printSyntax("Block");	
}

//Decl | Stmt 
void parseBlockItem() {
	//Decl
	if(curToken.Token == "INTTK" || curToken.Token == "CHARTK" || curToken.Token == "CONSTTK") {
		parseDecl();
	}
	//Stmt
	else {
		parseStmt();
	}
}

void parseStmt() {
	last_nonT = curToken.line_num;
	
	if(curToken.word == "if") {// 'if' '(' Cond ')' Stmt [ 'else' Stmt ] // j
		isifelse = true;
		 
		printcurToken();//	if
		nextToken();
		
		printcurToken();//	(
		nextToken();
		
		parseCond();
		
		parseErrorJ();
		
		parseStmt();
		
		if(curToken.word == "else") {
			printcurToken();//	else
			nextToken();	
			
			parseStmt();
		}
		isifelse = false;
	} 
	//'for' '(' [ForStmt] ';' [Cond] ';' [ForStmt] ')' Stmt 
	else if(curToken.word == "for") {
		isBorC = true;
		
		printcurToken();//	for
		nextToken();
		
		printcurToken();//	(
		nextToken();
		
		if(curToken.word != ";"){
			parseForStmt();
		}
		
		printcurToken();//	ù��°;
		nextToken();
		
		if(curToken.word != ";"){
			parseCond();
		}
		
		printcurToken();//	�ι�°;
		nextToken();
		
		if(curToken.word != ")"){
			parseForStmt();
		}
		
		printcurToken();//	)
		nextToken();
		
		parseStmt();
		isBorC = false;	//�ݺ��� �� �극��ũ ��Ƽ�� ó�� 
	} 
	//'break' ';' | 'continue' ';' // 
	else if(curToken.word == "break" || curToken.word == "continue"){
		printcurToken();//	break or continue
		last_nonT = curToken.line_num;
		nextToken();
		
		parseErrorI();
	} 
	//'return' [Exp] ';' // i
	else if(curToken.word == "return"){
		printcurToken();//	return
		last_nonT = curToken.line_num;
		int returnline = curToken.line_num;	
		
		if(!isifelse){
			isstmtreturn = true;
		}
		
		nextToken();
		
		if(curToken.word != ";"){//exp Ȯ�� 
			parseErrorF(returnline);
			parseExp();
		} 
		parseErrorI();
	}
	//'printf''('StringConst {','Exp}')'';' // i j
	else if(curToken.word == "printf"){
		printcurToken();//	printf
		int printlinenum = curToken.line_num;
		nextToken();
		
		printcurToken();//	(
		nextToken();
		
		string temp = curToken.word;
		printcurToken();//	StringConst
		last_nonT = curToken.line_num;
		nextToken();
		
		int expcnt = 0;
		while(curToken.word == ","){
			printcurToken();//	,
			nextToken();
			
			parseExp();
			expcnt++;
		}
		
		parseErrorJ();	
		parseErrorI();
		parseErrorL(temp, expcnt, printlinenum);
	}else if(curToken.word == "{"){
		parseBlock();
	}
	//LVal + exp
	else{
		//�ϴ� LVal���� �Ǵ� 
		int index = 0;
		int isLVal = 0;
		while (true)
		{
			if(curToken.word == ";")
				break;
			if(curToken.word == "=")
			{
				isLVal = 1;
				break;
			}
			index++;
			
			if(curpos >= Tlist_top){
				break;
			}else {
				nextToken();
			}
		}
		// LVal�� ��ġ�� ���ư���
		while(index)
		{
			preToken();
			index--;
		}
		//LVal '=' 'getint''('')'';' // i j
		//LVal '=' 'getchar''('')'';' // i j
		if(isLVal){
			parseErrorH(curToken.word);		//����� ident�� const���ϰ�� ó�� 
			parseLVal(-1);
			
			printcurToken();//	=
			nextToken();
			
			if(curToken.word == "getint" || curToken.word == "getchar"){
				printcurToken();//getint
				nextToken();
				
				printcurToken();//	(
				last_nonT = curToken.line_num;
				nextToken();
				
				parseErrorJ();
		
				parseErrorI();
			} 
			// LVal '=' Exp ';' // i
			else{
				parseExp();
				
				parseErrorI();
			}
		} 
		//[Exp] ';' // i
		else{
			if(curToken.word != ";"){
				parseExp();
			}
			parseErrorI();
		}
	}
	printSyntax("Stmt");
}

//ForStmt �� LVal '=' Exp
//if test for���� int������ �ɶ� 
void parseForStmt() {
//	if(curToken.word == "int"){
//		printcurToken();//decl for in int 
//		nextToken();
//	}
	parseErrorH(curToken.word);	//cosnt�� ��ȯ ���� ó�� 
	
	parseLVal(-1);
	
	printcurToken();//	=
	nextToken();
	
	parseExp();
	
	printSyntax("ForStmt");
}

//Exp �� AddExp 
int parseExp() {
	int type = INT;
	last_nonT = curToken.line_num;
	
	type = parseAddExp(type);
	
	printSyntax("Exp");
	
	return type;
}

//Cond �� LOrExp 
void parseCond() {
	last_nonT = curToken.line_num;
	
	parseLOrExp();
	
	printSyntax("Cond");
}

//LVal �� Ident ['[' Exp ']'] // k
int parseLVal(int type) {
	printcurToken();//	Ident
	parseErrorC(curToken.word);
	nextToken();
	
	if(curToken.word == "["){
		printcurToken();//	[
		last_nonT = curToken.line_num;
		nextToken();
		
		type = parseExp();
		
		parseErrorK();
	}
	
	printSyntax("LVal");
	return type;
}

//PrimaryExp �� '(' Exp ')' | LVal | Number | Character// j
int parsePrimaryExp(int type) {
	 if (curToken.word == "(") {//exp
        printcurToken();  // (
        nextToken();
        
        type = parseExp(); 
        
        parseErrorJ();
    } else if(isdigit(curToken.word[0])){//Number
    	type = INT;
		parseNumber();
	} else if(curToken.Token == "IDENFR"){
		type = parseLVal(type);
	} else {//Character
		type = CHAR;
		parseCharacter();
	} 
	 printSyntax("PrimaryExp");
	 return type;
}


//Number �� IntConst 
void parseNumber() {
	printcurToken();  // IntConst
    nextToken();
    
    printSyntax("Number"); 
}

//Character �� CharConst 
void parseCharacter() {
	printcurToken();  // charConst
    nextToken();
    
    printSyntax("Character"); 
}

//UnaryExp �� PrimaryExp | Ident '(' [FuncRParams] ')' | UnaryOp UnaryExp // j
int parseUnaryExp(int type) {
	nextToken();
	string temp1 = curToken.word;	//ident�϶�(�ޱ� 
	preToken();
	 
	if(curToken.word == "+" || curToken.word == "-" || curToken.word == "!"){
		parseUnaryOp();
		
		type = parseUnaryExp(type);
	} else if(curToken.Token == "IDENFR" && temp1 == "("){
//		isfuncparam = true;    //�Լ� �Ű����� �ޱ� 
		
		printcurToken();  // ident
		parseErrorC(curToken.word);
		last_nonT = curToken.line_num;
		last_func_line = curToken.line_num;
    	string identname = curToken.word;

    	for (int i = 0; i <= funcInfo_top; i++){	//���� �Լ��� �Ű����� 
    		if (funcInfo[i].name == identname) {
            	funcparse.push_back(funcInfo[i]);
				break;
       		}
		}
		type = funcparse.back().type;
		
		printfSymbol[print_top].name = funcparse.back().name + " " 
		+ to_string(funcparse.back().paramcnt) + " " + to_string(funcparse.back().expectedcnt);	//print only
		print_top++;
		
    	nextToken();
    	
    	printcurToken();  //(
    	nextToken();
    	
    	if(curToken.word != ")"){
    		if(curToken.word != ";"){// �׳� )parse err 
    			parseFuncRParams();
			}
		}
		
		if(!parseErrorJ()){		//����j�� �켱������ ���� 
			if(funcparse.back().expectedcnt != funcparse.back().paramcnt){
				parseErrorD(last_func_line);
			}
		}
		
		funcparse.pop_back();
//		isfuncparam = false;	//�Լ� �Ű����� ���� 
	} else{
		type = parsePrimaryExp(type);
	}
	printSyntax("UnaryExp");
	
	return type;
}

//UnaryOp �� '+' | '-' | '!' !�� Cond���� ���� 
void parseUnaryOp() {
	printcurToken();// + || - || !
    nextToken();
    
    printSyntax("UnaryOp"); 
}

//FuncRParams �� Exp { ',' Exp } 
int parseFuncRParams() {
	int paramscnt = 0;
	
	parseErrorE(paramscnt + 1);	 //1 �϶� cnt = 0 
	int type = parseExp();  // ù ��° �Ű����� ó��
	
//	if(isfuncparam){	//errorDó���� 
		paramscnt++;
		funcparse.back().expectedcnt++;
		printfSymbol[print_top].name = funcparse.back().name + "end " 
		+ to_string(funcparse.back().paramcnt) + " " + to_string(funcparse.back().expectedcnt);	//print only
		print_top++;
//	}
    
    while (curToken.word == ",") {
        printcurToken();  // ,
        nextToken();
        
        parseErrorE(paramscnt + 1);	    
        type = parseExp();  

//        if(isfuncparam){	//errorDó���� 
			paramscnt++;
			funcparse.back().expectedcnt++;
			printfSymbol[print_top].name = funcparse.back().name + "end " 
		+ to_string(funcparse.back().paramcnt) + " " + to_string(funcparse.back().expectedcnt);	//print only
		print_top++;
//		}
    }
    
    printSyntax("FuncRParams");
    return paramscnt;
}

//MulExp �� UnaryExp | MulExp ('*' | '/' | '%') UnaryExp 
int parseMulExp(int type) {
	parseUnaryExp(type); //UnaryExp+ �� ���� 

	printSyntax("MulExp");

	if(curToken.word == "*" || curToken.word == "/" || curToken.word == "%"){
		printcurToken();  // '*' | '/' | '%'
        nextToken();
		
		type = parseMulExp(type);
	}
	return type;
}

//AddExp �� MulExp | AddExp ('+' | '-') MulExp 
int parseAddExp(int type) {
	parseMulExp(type);
	
	printSyntax("AddExp");
	
	if(curToken.word == "+" || curToken.word == "-"){
		printcurToken();  // '+' | '-'
        nextToken();
        
		type = parseAddExp(type);
	}
	return type;
}

//RelExp �� AddExp | RelExp ('<' | '>' | '<=' | '>=') AddExp 
void parseRelExp() {
	parseAddExp(-1);
	
	printSyntax("RelExp");
	
	if(curToken.word == "<" || curToken.word == ">" || curToken.word == "<=" || curToken.word == ">="){
		printcurToken();  // '<' | '>' | <= | >=
        nextToken();
		
		parseRelExp();
	}
}

//EqExp �� RelExp | EqExp ('==' | '!=') RelExp 
void parseEqExp() {
	parseRelExp();

	printSyntax("EqExp");
		
	if(curToken.word == "==" || curToken.word == "!="){
		printcurToken();  // == | !=
        nextToken();
		
		parseEqExp();
	}
}

//LAndExp �� EqExp | LAndExp '&&' EqExp
void parseLAndExp() {
	parseEqExp();
	
	printSyntax("LAndExp");
	
	parseErrorA();
	
	if(curToken.Token == "AND"){
		printcurToken();  // &&
        nextToken();
		
		parseLAndExp();
	}
}

//LOrExp �� LAndExp | LOrExp '||' LAndExp
void parseLOrExp() {
	parseLAndExp();
	
	printSyntax("LOrExp");
	
	parseErrorA();
	
	if(curToken.Token == "OR"){
		printcurToken();  // ||
        nextToken();
		
		parseLOrExp();
	}
}

//ConstExp �� AddExp ���� ident�� �ݵ�� ò�� 
void parseConstExp() {
	last_nonT = curToken.line_num;
	
	parseAddExp(-1);
	
	printSyntax("ConstExp");
}
 
void parseErrorA(){
	if(curToken.Token == "EAND"){
		push_err_list('a');
		nextToken();
		
		parseLAndExp();
	}else if(curToken.Token == "EOR"){
		push_err_list('a');
		nextToken();
		
		parseLOrExp();
	}
}
 
bool parseErrorB(string name, int type, int kind, int isconst, int nowScope){
	for (int i = ST_top - 1; i >= 0; i--) {
        if (symbolTable[i].scope == nowScope && symbolTable[i].name == name) {
            push_err_list('b');
            return false;
        }
        if(isequalScope){
        	if (symbolTable[i].scope == curScope) {	
        		if (symbolTable[i].name == name) { 
                	push_err_list('b');
                	return false;
            	}
			}
		} 
    }

   add_s_Table(name, type, kind, isconst);
    
	return true;
}

void parseErrorC(string name) {
    bool isFound = false;
    for (int i = 0; i < ST_top; i++) {
        if (symbolTable[i].name == name) {
            isFound = true;
            break;
        }
    }
    if (!isFound) {
        push_err_list('c'); // ���ǵ��� ���� ���� ���� ó��
    }
}

void parseErrorD(int funcline) {
    push_err_list('d', funcline);
    return; 
}

void parseErrorE(int param_num) {

	funcparam& curFunc = funcparse.back();
	
	if(curFunc.paramcnt == 0){//�Ű����� ������� üũ x 
		return;
	}
	//�����϶� 
	if(curToken.Token == "IDENFR"){
		for(int i = ST_top - 1; i >= 0 ; i--){//�ش� ���� �������� 
			if(curToken.word == symbolTable[i].name){
				SymbolTemp = symbolTable[i];
				printfSymbol[print_top].name = SymbolTemp.name;	//print only
				printfSymbol[print_top].kind = SymbolTemp.kind;
				printfSymbol[print_top].type = SymbolTemp.type;
				print_top++;
				break;
			}
		}	
		if(curFunc.paramkind[param_num - 1] == 3){//��밪�� �迭�ϋ�  
			if(SymbolTemp.type != curFunc.paramtype[param_num - 1] || 
				SymbolTemp.kind != curFunc.paramkind[param_num - 1]){
				push_err_list('e', last_func_line);
			}
		} else if(curFunc.paramkind[param_num - 1] == 0){//�Ϲ� ����
			nextToken();//�迭�� ���Ϸ� �޴°��ó�� 
			nextToken();
			if(isdigit(curToken.word[0])){
				preToken();
				preToken();
				return;
			}
			preToken();
			preToken();	//ó���� 
			
			if(SymbolTemp.kind == 3){
				push_err_list('e', last_func_line);
			} 
		}
	} else if(isdigit(curToken.word[0])){//�����̰� �迭�� �ƴϸ� ��Ʈ 
	
		printfSymbol[print_top].name = curToken.word;	//print only
		printfSymbol[print_top].kind = 0;
		printfSymbol[print_top].type = 0;
		print_top++;
	
		if(curFunc.paramtype[param_num - 1] != 0 || curFunc.paramkind[param_num - 1] == 3){//�Լ� �Ű����� Ÿ������ �����ؾ��� 
			push_err_list('e', last_func_line);
		} 
	} else if(isalpha(curToken.word[0]) || curToken.word[0] == '\''){ 
		printfSymbol[print_top].name = curToken.word;	//print only
		printfSymbol[print_top].kind = 0;
		printfSymbol[print_top].type = 1;
		print_top++;
		
		if(curFunc.paramtype[param_num - 1] != 1){
			push_err_list('e', last_func_line);
		} 
	} 

	return;
}

void parseErrorF(int linenum){
	if(!isneedreturn){
		push_err_list('f', linenum);
	}
}

void parseErrorG(){
	if(isneedreturn){
		if(!isstmtreturn){
			push_err_list('g');
		}
	}
}

void parseErrorH(string name){
	for (int i = 0; i < ST_top; i++) {
        if (symbolTable[i].name == name) {
            if(symbolTable[i].isconst == 1){
				push_err_list('h');
			}
            break;
        }
    }	
}

void parseErrorI(){
	if (curToken.word != ";"){
		push_err_list('i', last_nonT);
	}
	else{
		printcurToken();
		nextToken();
	}
}

bool parseErrorJ(){
	if (curToken.word != ")"){
		push_err_list('j', last_nonT);
		return true;
	}
	else{
		printcurToken();
		nextToken();
	}
	return false;
}

void parseErrorK(){
	if (curToken.word != "]"){
		push_err_list('k', last_nonT);
	}
	else{
		printcurToken();
		nextToken();
	}
}

void parseErrorL(string formatString, int print_param_cnt, int printlinenum) {
    int formatCount = 0;
    for (int i = 0; i < formatString.length(); i++) {
        if (formatString[i] == '%' && (formatString[i + 1] == 'd' || formatString[i + 1] == 'c')) { // '%' ���ڰ� ���� ������ ���
            formatCount++;
        }
    }
    
    if (formatCount != print_param_cnt) {
        push_err_list('l', printlinenum); 
    }
}

void parseErrorM(){
	if(!isBorC){
		push_err_list('m');
	}
}

int main() {
    init();
    Lexical_Analysis();
//    output_Syntax();
//    print_Lexical();
    Syntax_Analysis();
    print_symbol_list();
    cout << "\n\n" << endl;
    print_err_list();
    
    //	�Լ����� ��� 
    cout << "\n\n";
	for(int i = 0; i < funcInfo_top; i++){
		string temp1;
		if(funcInfo[i].type == 0){
			temp1 = "Int";
		}else if(funcInfo[i].type == 1){
			temp1 = "Char";
		}else {
			temp1 = "Void";
		}
		cout << temp1 << " " << funcInfo[i].name << " " <<
		funcInfo[i].paramcnt << " ";
		for (int j = 0; j < funcInfo[i].paramcnt; ++j) {
    	int type1 = funcInfo[i].paramtype[j];
    	int type2 = funcInfo[i].paramkind[j];
		string temp2;
		if(type1 == 0){
			temp2 = "Int";
		}else if(type1 == 1){
			temp2 = "Char";
		}else if(type1 == 2){
			temp2 = "Void";
		}
		if(type2 == 3){
			temp2 += "Arr";
		}
        cout << temp2 << endl;
    	}
    	cout << "\n";
	} 
	
	for(int i = 0; i < print_top; i++){
		string temp;
		if(printfSymbol[i].type == 0){
			temp = "Int";
		}else if(printfSymbol[i].type == 1){
			temp = "Char";
		}else if(printfSymbol[i].type == 2){
			temp = "Void";
		}
		if(printfSymbol[i].kind == 3){
			temp += "Arr";
		}else if(printfSymbol[i].kind == 1){
			temp += "Func";
		}
		cout << printfSymbol[i].name << " " 
		<< temp << endl;
	}
	
    inputFile.close();
    outputFile.close();
    outputFile2.close();
    errorFile.close();
    return 0;
}

